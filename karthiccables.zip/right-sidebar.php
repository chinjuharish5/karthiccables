<aside id="sidebar_right" class="nano">
		<div class="sidebar_right_content nano-content">
				<div class="tab-block sidebar-block br-n">
						<ul class="nav nav-tabs tabs-border nav-justified hidden">
								<li class="active">
										<a href="#sidebar-right-tab1" data-toggle="tab">Tab 1</a>
								</li>
								<li>
										<a href="#sidebar-right-tab2" data-toggle="tab">Tab 2</a>
								</li>
								<li>
										<a href="#sidebar-right-tab3" data-toggle="tab">Tab 3</a>
								</li>
						</ul>
						<div class="tab-content br-n">
								<div id="sidebar-right-tab1" class="tab-pane active">

										<h5 class="title-divider text-muted mb20"> Server Statistics <span class="pull-right"> 2013 <i class="fa fa-caret-down ml5"></i> </span> </h5>
										<div class="progress mh5">
												<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 44%">
														<span class="fs11">DB Request</span>
												</div>
										</div>
										<div class="progress mh5">
												<div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 84%">
														<span class="fs11 text-left">Server Load</span>
												</div>
										</div>
										<div class="progress mh5">
												<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 61%">
														<span class="fs11 text-left">Server Connections</span>
												</div>
										</div>

										<h5 class="title-divider text-muted mt30 mb10">Traffic Margins</h5>
										<div class="row">
												<div class="col-xs-5">
														<h3 class="text-primary mn pl5">132</h3>
												</div>
												<div class="col-xs-7 text-right">
														<h3 class="text-success-dark mn"> <i class="fa fa-caret-up"></i> 13.2% </h3>
												</div>
										</div>

										<h5 class="title-divider text-muted mt25 mb10">Database Request</h5>
										<div class="row">
												<div class="col-xs-5">
														<h3 class="text-primary mn pl5">212</h3>
												</div>
												<div class="col-xs-7 text-right">
														<h3 class="text-success-dark mn"> <i class="fa fa-caret-up"></i> 25.6% </h3>
												</div>
										</div>

										<h5 class="title-divider text-muted mt25 mb10">Server Response</h5>
										<div class="row">
												<div class="col-xs-5">
														<h3 class="text-primary mn pl5">82.5</h3>
												</div>
												<div class="col-xs-7 text-right">
														<h3 class="text-danger mn"> <i class="fa fa-caret-down"></i> 17.9% </h3>
												</div>
										</div>

										<h5 class="title-divider text-muted mt40 mb20"> Server Statistics <span class="pull-right text-primary fw600">USA</span> </h5>
										<div id="sidebar-right-map" class="hide-jzoom" style="width: 100%; height: 180px;"></div>

								</div>
								<div id="sidebar-right-tab2" class="tab-pane"></div>
								<div id="sidebar-right-tab3" class="tab-pane"></div>
						</div>
						<!-- end: .tab-content -->
				</div>
		</div>
</aside>
