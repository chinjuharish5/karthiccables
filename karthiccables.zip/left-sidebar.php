<aside id="sidebar_left" class="nano nano-primary">
		<div class="nano-content">
			<div class="bg" style="z-index: 2; position: relative; width: 100%; min-height: 50px; padding: 5px 39px 4px; background: #fafafa; border-bottom: 1px solid #e0e0e0;">
				<img src="https://ccrmcdn.iconwavetech.com/templates/yourlogohere.png" height="40px" width="120px"> 				
			</div>
				<!-- Start: Sidebar Header -->
				<!--<header class="sidebar-header">
						<div class="user-menu">
								<div class="row text-center mbn">
										<div class="col-xs-4">
												<a href="dashboard.html" class="text-primary" data-toggle="tooltip" data-placement="top" title="Dashboard">
														<span class="glyphicons glyphicons-home"></span>
												</a>
										</div>
										<div class="col-xs-4">
												<a href="pages_messages.html" class="text-info" data-toggle="tooltip" data-placement="top" title="Messages">
														<span class="glyphicons glyphicons-inbox"></span>
												</a>
										</div>
										<div class="col-xs-4">
												<a href="pages_profile.html" class="text-alert" data-toggle="tooltip" data-placement="top" title="Tasks">
														<span class="glyphicons glyphicons-bell"></span>
												</a>
										</div>
										<div class="col-xs-4">
												<a href="pages_timeline.html" class="text-system" data-toggle="tooltip" data-placement="top" title="Activity">
														<span class="glyphicons glyphicons-imac"></span>
												</a>
										</div>
										<div class="col-xs-4">
												<a href="pages_profile.html" class="text-danger" data-toggle="tooltip" data-placement="top" title="Settings">
														<span class="glyphicons glyphicons-settings"></span>
												</a>
										</div>
										<div class="col-xs-4">
												<a href="pages_gallery.html" class="text-warning" data-toggle="tooltip" data-placement="top" title="Cron Jobs">
														<span class="glyphicons glyphicons-restart"></span>
												</a>
										</div>
								</div>
						</div>
				</header>-->
				<!-- End: Sidebar Header -->

				<!-- sidebar menu -->
				<ul class="nav sidebar-menu">
						<!--<li class="sidebar-label pt20">Menu</li>
						<li>
								<a href="pages_calendar.html">
										<span class="fa fa-calendar"></span>
										<span class="sidebar-title">Calendar</span>
								</a>
						</li>
						<li>
								<a href="documentation/index.html">
										<span class="glyphicons glyphicons-book_open"></span>
										<span class="sidebar-title">Documentation</span>
								</a>
						</li>
						<li class="active">
								<a href="dashboard.html">
										<span class="glyphicons glyphicons-home"></span>
										<span class="sidebar-title">Dashboard</span>
								</a>
						</li>-->
						<li class="sidebar-label pt15">Menu</li>
						<li class="active">
								<a href="dashboard.html">
										<span class="glyphicons glyphicons-home"></span>
										<span class="sidebar-title">Dashboard</span>
								</a>
						</li>						
						<li>
								<a class="accordion-toggle" href="#">
										<span class="glyphicons glyphicons-fire"></span>
										<span class="sidebar-title">Users</span>
										<span class="caret"></span>
								</a>
								<ul class="nav sub-nav">
										<li>
											<a href="area_listing.php">
											<span class="glyphicons glyphicons-book"></span> Area</a>
										</li>
										<li>
											<a href="state_listing.php">
											<span class="glyphicons glyphicons-show_big_thumbnails"></span> State </a>
										</li>
										<li>
											<a href="district_listing.php">
											<span class="glyphicons glyphicons-sampler"></span> District </a>
										</li>
										<li>
											<a href="city_listing.php">
											<span class="glyphicons glyphicons-sampler"></span> City </a>
										</li>										
										<li>
											<a href="company_listing.php">
											<span class="glyphicons glyphicons-sampler"></span> Company </a>
										</li>										
										<li>
											<a href="tariff_listing.php">
											<span class="glyphicons glyphicons-sampler"></span> Tariff </a>
										</li>
										<li>
											<a href="reason_listing.php">
											<span class="glyphicons glyphicons-sampler"></span> Reason </a>
										</li>
										<li>
											<a href="user_listing.php">
											<span class="glyphicons glyphicons-sampler"></span> Users </a>
										</li>										
								</ul>
						</li>
						<li>
								<a class="accordion-toggle" href="#">
										<span class="glyphicons glyphicons-cup"></span>
										<span class="sidebar-title">Admin Menus</span>
										<span class="caret"></span>
								</a>
								<ul class="nav sub-nav">
										<li>
												<a href="admin_forms-elements.html">
														<span class="glyphicons glyphicons-edit"></span> Payment </a>
										</li>
										<li>
												<a href="admin_forms-widgets.html">
														<span class="glyphicons glyphicons-calendar"></span> My Profile </a>
										</li>
										<li>
												<a href="admin_forms-layouts.html">
														<span class="glyphicons glyphicons-more_windows"></span> Usage </a>
										</li>
								</ul>
						</li>
				</ul>
				<!--<div class="sidebar-toggle-mini">
						<a href="#">
								<span class="fa fa-sign-out"></span>
						</a>
				</div>-->
		</div>
</aside>
