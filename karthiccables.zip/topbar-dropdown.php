<div id="topbar-dropmenu">
	<div class="topbar-menu row">
		<div class="col-xs-4 col-sm-2">
			<a href="#" class="metro-tile bg-success">
				<span class="metro-icon glyphicons glyphicons-inbox"></span>
				<p class="metro-title">Messages</p>
			</a>
		</div>
		<div class="col-xs-4 col-sm-2">
			<a href="#" class="metro-tile bg-info">
				<span class="metro-icon glyphicons glyphicons-parents"></span>
				<p class="metro-title">Users</p>
			</a>
		</div>
		<div class="col-xs-4 col-sm-2">
			<a href="#" class="metro-tile bg-alert">
				<span class="metro-icon glyphicons glyphicons-headset"></span>
				<p class="metro-title">Support</p>
			</a>
		</div>
		<div class="col-xs-4 col-sm-2">
			<a href="#" class="metro-tile bg-primary">
				<span class="metro-icon glyphicons glyphicons-cogwheels"></span>
				<p class="metro-title">Settings</p>
			</a>
		</div>
		<div class="col-xs-4 col-sm-2">
			<a href="#" class="metro-tile bg-warning">
				<span class="metro-icon glyphicons glyphicons-facetime_video"></span>
				<p class="metro-title">Videos</p>
			</a>
		</div>
		<div class="col-xs-4 col-sm-2">
			<a href="#" class="metro-tile bg-system">
				<span class="metro-icon glyphicons glyphicons-picture"></span>
				<p class="metro-title">Pictures</p>
			</a>
		</div>
	</div>
</div>